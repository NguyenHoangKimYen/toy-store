const Product = require('../models/product.model.js');

const findAll = async (filter = {}, options = {}) => {
    return Product.find(filter)
        .populate([
            {
                path: "categoryId",
                select: "name slug description"
            },
            {
                path: "tags",
                select: "name slug"
            },
            // {
            //     path: "discountCode",
            //     select: "code discountPercentage validUntil"
            // }
        ])
        .skip(options.skip || 0)
        .limit(options.limit || 20)
        .sort(options.sort || { createdAt: -1 });
}

const findById = async (id) => {
    return Product.findById(id)
        .populate([
            {
                path: "categoryId",
                select: "name slug description"
            },
            {
                path: "tags",
                select: "name slug"
            },
            // {
            //     path: "discountCode",
            //     select: "code discountPercentage validUntil"
            // }
        ])
}

const findBySlug = async (slug) => {
    return Product.findOne({ slug })
        .populate([
            {
                path: "categoryId",
                select: "name slug description"
            },
            {
                path: "tags",
                select: "name slug"
            },
            // {
            //     path: "discountCode",
            //     select: "code discountPercentage validUntil"
            // }
        ])
}

const create = async (data) => {
    const product = new Product(data);
    return product.save();
}

const update = async (id, data) => {
    return Product.findByIdAndUpdate(id, data, { new: true });
}

const remove = async (id) => {
    return Product.findByIdAndDelete(id);
}

const updateImages = async (id, imageUrls) => {
    return Product.findByIdAndUpdate(id, { $push: { images: { $each: imageUrls } } }, { new: true });
}

module.exports = {
    findAll,
    findById,
    findBySlug,
    create,
    update,
    remove,
    updateImages
};
