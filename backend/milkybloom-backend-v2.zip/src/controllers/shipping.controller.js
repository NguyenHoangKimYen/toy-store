const Address = require('../models/address.model.js');
const { calculateDistance, calculateShippingFee } = require('../services/shipping.service.js');

// Giả sử kho cố định tại TDTU
const warehouse = { lat: 10.762622, lng: 106.660172 };

// /api/shipping/calculate
const calculateShipping = async (req, res, next) => {
  try {
    const { addressId, from, to, weight = 1 } = req.body;
    let destination = null;

    if (addressId) {
      const address = await Address.findById(addressId);
      if (!address) {
        return res.status(404).json({ success: false, message: 'Address not found' });
      }
      destination = { lat: address.lat, lng: address.lng };
    } else if (to) {
      destination = to;
    } else {
      return res.status(400).json({ success: false, message: 'Missing addressId or destination' });
    }

    const origin = from || warehouse;
    const distanceKm = calculateDistance(origin.lat, origin.lng, destination.lat, destination.lng);
    const shippingFee = calculateShippingFee(distanceKm, weight);

    res.json({
      success: true,
      data: {
        from: origin,
        to: destination,
        distanceKm: distanceKm.toFixed(2),
        weight,
        shippingFee,
      },
    });
  } catch (error) {
    next(error);
  }
};

module.exports = { calculateShipping };
